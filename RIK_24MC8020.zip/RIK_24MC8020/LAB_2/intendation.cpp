#include<iostream>
#include <iomanip>
#include<string>
#include <vector>

using namespace std;

bool isEmpty(string & str){
    for(char ch:str){
        if(ch!=' '||ch!='\t'){
            return true;
        }
      
      
      return false;
    
      
    }
}


void indent(vector<string>codeLines){
    int tab = 0;
    for(int i=0;codeLines[i]!="";i++){
        string line = codeLines[i];
        int index=0;
        while(line[index]==' '||line[index]=='\t');
        index++;


        string trimmed="";
        for(int j=index;line[j]!='\0';j++){
            trimmed=trimmed+line[j];
        }

        if(trimmed[0]=='}'){
            tab--;
        }

        cout<<setw(tab*4)<<""<<trimmed<<endl;

        for(int k=0;trimmed[k]!='\0';++k){
            if(trimmed[k]=='{'){
                tab++;
                break;
            }
        }

    }
}

int main(){

    vector<string>code;
    
    code.push_back("int main(){");
    code.push_back("switch(inp){");
    code.push_back("sinPlot();");
    code.push_back("}");

    indent(code);

    return 0;
}