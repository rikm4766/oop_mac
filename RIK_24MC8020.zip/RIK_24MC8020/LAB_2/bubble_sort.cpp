#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

vector<int> arr ;



int main(){

char c;

cout<<"Give Input Of The Array "<<endl;
cout<<"Press $ to exit the array Input"<<endl;

while(1){
	cin>>c;
	
	if(c=='$'){
		break;
	}
	
	else{
	
	arr.push_back((c-'0'));
	
	
	}
}


for(int i = 0;i<arr.size();i++){

	for(int j=0;j<(arr.size()-1);j++){
		
		if(arr[j]>arr[j+1]){
		
			int temp = arr[j+1];
			arr[j+1]=arr[j];
			arr[j]=temp;
			
		}
		
	}
	
}
cout<<"Your Sorted Array is "<<endl;


for(int i :arr){
cout<<i<<endl;
}

return 0;

}
