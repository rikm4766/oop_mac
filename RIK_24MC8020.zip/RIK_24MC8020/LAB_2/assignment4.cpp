#include <iostream>
#include <vector>
#include <string>
using namespace std;

//function to get the only first name
string getFirstName(string  fullName){

	int spacePos=fullName.find(' ');
	if(spacePos != string::npos){
		return fullName.substr(0,spacePos);
	}
	return fullName;
}

void bubbleSort(vector<string> &fullname){

	int n= fullname.size();

	for(int i=0;i<n;i++){
		for(int j=0;j<n-1;j++){
			string n1=getFirstName(fullname[j]);
			string n2=getFirstName(fullname[j+1]);

			if(n1>n2){
				string temp;
				temp=fullname[j];
				fullname[j]=fullname[j+1];
				fullname[j+1]=temp;

				
			}
		}
	}


	for(int i=0;i<n;i++){
		cout<<fullname[i]<<endl;
	}

}


int main(){




bubbleSort(names);




return 0;
}
