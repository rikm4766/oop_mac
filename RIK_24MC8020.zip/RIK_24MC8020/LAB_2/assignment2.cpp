#include <iomanip>
#include <math.h>
#include <iostream>
using namespace std;

void sinPlot(){

	int startAngle;
	cout<<"Enter the start Angle ";
	cin>>startAngle;
	int endAngle; 
	cout<<"Enter the End Angle ";
	cin>>endAngle;
	cout<<"Enter the character you want to plot ";
	char c ; cin>>c;
	int step;
	cout<<"Enter the steps ";
	cin>>step;
	for(int i =startAngle;i<endAngle;i+=step){
		
		int x = floor(sin(i*3.14/180)*40);
		
		
		if(x>0){
		cout <<setw(45) << setfill(' ') << "|" << setw(x) << setfill(c) << '+' << endl;
		}
		else{
		x=abs(x);
			x=abs(x);
			cout <<setw(45-x) << setfill(' ') << '+' << setw(x) << setfill(c) << "|" << endl ;
		}
	}
	


}

void cosPlot(){
	int startAngle;
	cout<<"Enter the start Angle ";
	cin>>startAngle;
	int endAngle; 
	cout<<"Enter the End Angle ";
	cin>>endAngle;
	cout<<"Enter the character you want to plot ";
	char c ; cin>>c;
	int step;
	cout<<"Enter the steps ";
	cin>>step;
	for(int i =startAngle;i<endAngle;i+=step){
		
		int x = floor(cos(i*3.14/180)*40);
		
		
		if(x>0){
		cout <<setw(45) << setfill(' ') << "|" << setw(x) << setfill(c) << '+' << endl;
		}
		else{
		x=abs(x);
			x=abs(x);
			cout <<setw(45-x) << setfill(' ') << '+' << setw(x) << setfill(c) << "|" << endl ;
		}
	}
	

}

int main(){
	cout<<"Press 1 for sin plotting"<<endl;
	cout<<"press 2 for cos Plotting"<<endl;
 char inp;
 cin>>inp;
 
 switch(inp){
 
 	case '1':
 		sinPlot();
 		break;
 	case '2':
 		cosPlot();
 
 }
	
return 0;
}



