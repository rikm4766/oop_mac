#include <iostream>
#include <string>
#include <iomanip>
#include <algorithm>

using namespace std;


void namePrinter(string name){
    int len= name.length();
    string org=name;
    reverse(name.begin(),name.end());

    string complete=org+name;

    for(int i=0;i<len;++i){
        int last=(complete.length()-(2*i+1));
        cout<<setw(i)<<"";
        cout<<complete.substr(i,last)<<endl;
    }

}

int main(){
    string name="subrata";
    namePrinter(name);

    return 0;
}