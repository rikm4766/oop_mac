#include<iostream>
#include<iomanip>
#include<iomanip>

using namespace std;

int main(void){
    int tab=0;
    string temp;
    while(1){
        getline(cin,temp);

        int opostion=temp.find('{');
        int cpostion=temp.find('}');

        cout<<setfill(' ')<<setw(tab*5)<<""<<temp<<endl;
        
        if(opostion>=0){
            tab++;
        }
        else if(cpostion>=0){
            tab--;
            if(tab<0){
                tab=0;
            }
        }


    }

    return 0;
}