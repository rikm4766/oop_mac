#include<iostream>
#include<fstream>
#include<string>
using namespace std;

ofstream myfile("helloworld.txt");

void openFile(){
    if(!myfile.is_open()){
        cerr<<"unable to create file"<<endl;
        exit(0);
    }
}

void write(string temp){
    myfile<<temp<<endl;
}

int main(void){

    openFile();
    string temp;
    while(1){
        getline(cin,temp);
        write(temp);
    }

    return 0;
}