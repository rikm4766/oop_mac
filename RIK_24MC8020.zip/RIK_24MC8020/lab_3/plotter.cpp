#include <iomanip>
#include <math.h>
#include <iostream>
#include<cstdlib>
#include<fstream>

using namespace std;



void sinPlot(int startAngle,int endAngle,char c,int step,string filename){
	ofstream sinfile(filename);
	if(!sinfile.is_open()){
		cout<<"unable to write sin file"<<endl;
		exit(0);
	}
	
	// int startAngle;
	// cout<<"Enter the start Angle ";
	// cin>>startAngle;
	// int endAngle; 
	// cout<<"Enter the End Angle ";
	// cin>>endAngle;
	// cout<<"Enter the character you want to plot ";
	// char c ; cin>>c;
	// int step;
	// cout<<"Enter the steps ";
	// cin>>step;
	for(int i =startAngle;i<endAngle;i+=step){
		
		int x = floor(sin(i*3.14/180)*40);
		
		
		if(x>0){
		sinfile <<setw(45) << setfill(' ') << "|" << setw(x) << setfill(c) << '+' << endl;
		}
		else{
		x=abs(x);
			x=abs(x);
			sinfile <<setw(45-x) << setfill(' ') << '+' << setw(x) << setfill(c) << "|" << endl ;
		}
	}
	sinfile.close();


}

void cosPlot(int startAngle,int endAngle,char c,int step,string filename){
	ofstream cosfile(filename);
	// int startAngle;
	// cout<<"Enter the start Angle ";
	// cin>>startAngle;
	// int endAngle; 
	// cout<<"Enter the End Angle ";
	// cin>>endAngle;
	// cout<<"Enter the character you want to plot ";
	// char c ; cin>>c;
	// int step;
	// cout<<"Enter the steps ";
	// cin>>step;
	for(int i =startAngle;i<endAngle;i+=step){
		
		int x = floor(cos(i*3.14/180)*40);
		
		
		if(x>0){
		cosfile <<setw(45) << setfill(' ') << "|" << setw(x) << setfill(c) << '+' << endl;
		}
		else{
		x=abs(x);
			x=abs(x);
			cosfile <<setw(45-x) << setfill(' ') << '+' << setw(x) << setfill(c) << "|" << endl ;
		}
	}
	
	cosfile.close();
}

int main(int argc,char * argv[]){
	// cout<<"Press 1 for sin plotting"<<endl;
	// cout<<"press 2 for cos Plotting"<<endl;

	int startAngle;
	int endAngle;
	char c;
	int step;
	string filename;
	string funcName;

	funcName=argv[1];
	startAngle=atoi(argv[2]);
	endAngle=atoi(argv[3]);
	c=char(argv[5][0]);
	step=atoi(argv[4]);
	filename=argv[6];

//  char inp;
//  cin>>inp;
 
//  switch(inp){
 
//  	case '1':
//  		sinPlot();
//  		break;
//  	case '2':
//  		cosPlot();
 
//  }
	// cout<<startAngle<<endl<<endAngle<<endl<<c<<endl<<step<<filename<<endl;
	
	// cout<<c<<endl;
	// c='*';
	if(funcName=="sin"){
	sinPlot(startAngle,endAngle,c,step,filename);
	}
	// cosplot
	else if(funcName=="cos"){
		cosPlot(startAngle,endAngle,c,step,filename);
	}
	// int num=atoi(argv[1]);

	// cout<<num<<endl;

return 0;
}



