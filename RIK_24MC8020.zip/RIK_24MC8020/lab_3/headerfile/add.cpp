#include<iostream>
#include <string>
#include "mymath.h"

using namespace std;
int main(int argc ,char *argv[]){
    string num1=argv[1];
    string num2=argv[2];
    string result=addString(num1,num2);
    cout<<result<<endl;
}

