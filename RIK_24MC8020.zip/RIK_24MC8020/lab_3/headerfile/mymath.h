#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using namespace std;


bool readElements(string & num1,string & num2){
    ifstream inputFile("Sumelements.txt");
    if(!inputFile.is_open()){
        ofstream newFile("sumelements.txt");
        if(newFile.is_open()){
            newFile<<"12345\n67890";
            newFile.close();
            cout<<"templete created"<<endl;
        }
        return false;
    }
    getline(inputFile,num1);
    getline(inputFile,num2);
    inputFile.close();

    return true;
}

void saveFile(const string &answer){
    ofstream file("sumanswer.txt");
    if(file.is_open()){
        file<<"your answer is "<<answer<<endl;
        cout<<"Result saved"<<endl;

    }
    else{
        cout<<"error thorwed";
        exit(1);
    }
}

string addString(const string &num1,const string &num2){
    string n1=num1;
    string n2=num2;
    reverse(n1.begin(),n1.end());
    reverse(n2.begin(),n2.end());
    string result;
    int carry=0;
    int maxLength=max(n1.length(),n2.length());
    for(int i=0;i<maxLength;++i){
        int digit1;
        int digit2;
        if(i<n1.length()){
            digit1=n1[i]-'0';
        }
        else{
            digit1=0;
        }
        if(i<n2.length()){
            digit2=n2[i]-'0';
        }
        else{
            digit2=0;
        }
        int sum=digit1+digit2+carry;
        result.push_back((sum%10)+'0');
        carry=sum/10;
    }
    if(carry){
        result.push_back(carry+'0');
    }
    reverse(result.begin(),result.end());
    return result;
}