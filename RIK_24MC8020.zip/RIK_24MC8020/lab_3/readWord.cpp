#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>

using namespace std;

int words;
int lines;

void readFile(string fileName){
    ifstream file(fileName);
    if(!file.is_open()){

        cerr<<"unable to read the file"<<endl;
        exit(0);
    }
    string word;
    
    while(file>>word){
        // cout<<word<<endl;
        int pos=word.find('.');
        if(pos>0){
            words++;
            lines++;
        }
        words++;
    }
    lines++;
    file.close();
    
}

void stringMethod(string filename){
    ifstream file(filename);
    string completeline;
    string temp;
    if(!file.is_open()){
        cerr<<"unable to open the file"<<endl;
    }
    while(getline(file,temp)){
        completeline+=temp;
    }
    cout<<"Total No of character is "<<temp.length()<<endl;
}


int main(int argc,char * argv[]){
    readFile(argv[1]);
    stringMethod(argv[1]);
    cout<<"Total No Of Words Is: "<<words<<endl;
    cout<<"Total Nof Of Lines Is: "<<lines<<endl;

    return 0;
}