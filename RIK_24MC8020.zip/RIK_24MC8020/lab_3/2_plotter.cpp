#include<iostream>
#include<iomanip>
#include<string>

int main(void){

    return 0;
}