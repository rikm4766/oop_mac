#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

string warmUser="julie";
string helloWelcomeUser= "neal";

int main(){
	
	string user;
	cout<<"Please Enter UserName"<<endl;
	getline(cin,user);
	transform(user.begin(),user.end(),user.begin(),::tolower);
	//cout<<user<<endl;
	if(user==warmUser){
		cout<<"Warm Welcome to "<<user;
		}
		
	else if(user==helloWelcomeUser){
		cout<<"hello "<<user;
	}
	
	else{
		cout<<"Welcome "<<user;
	}

return 0;
}
