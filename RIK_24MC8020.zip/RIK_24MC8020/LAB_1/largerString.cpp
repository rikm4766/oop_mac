//Program to find the Larger String and print the larger one
#include<iostream>
#include <string>
using namespace std;
int main(){

	string firstString;
	string secondString;

	cout<<"Enter Your First String: ";
	getline(cin,firstString);
	cout<<"Enter Your Second String: ";
	getline(cin,secondString);

	int firstSize = firstString.length();
	int secondSize = secondString.length();

	if(firstSize>=secondSize){
		cout<<firstString<<endl;
		}
	else{
		cout<<"The Largest String is "<<secondString<<endl;
	}
//cout<<firstString<<endl<<secondString<<endl;

return 0;
}
