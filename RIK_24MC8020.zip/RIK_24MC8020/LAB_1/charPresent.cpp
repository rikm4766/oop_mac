//cpp Program to Find if the target String Present In the Main String Or Not

#include <iostream>
#include <string>

using namespace std;

int main(){
string userInput;
string target;
cout<<"Give The Complete String"<<endl;
getline(cin,userInput);
cout<<"Give the Letter or word to find"<<endl;
getline(cin,target);

int value= userInput.find(target);
if(value==-1){
	cout<<"Your Target String/Letter is Not Found"<<endl;
	}
	else{
		cout<<"Your Target Value Found in the index: "<<value<<endl;
	}
return 0;
}
