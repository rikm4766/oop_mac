//This Code Print a String
//code stores a string in the variable and then print that string

#include <iostream>
#include <string>
using namespace std;

int main(){
	string myName;
	cout<<"Enter Your Name"<<endl;
	
	getline(cin,myName);
	

	cout<<"hello world"<<endl;
	
	cout<<"greetings from "<<myName<<endl;
	
	
	return 0;
}
