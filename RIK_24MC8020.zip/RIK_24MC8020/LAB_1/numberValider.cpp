#include <iostream>
#include <string>
#include <algorithm>
#include <vector>


using namespace std;

vector<int>answerVector;

void summer(string number){
string answerString;
//cout<<"summer called";
reverse(number.begin(),number.end());
	int elementPush=0;
	int carry = 1;
	int tnumber = 0;
	
	for(int i = 0;i<number.length();i++){
	tnumber=((number[i]-'0')+carry);
	carry=tnumber/10;
	elementPush=tnumber%10;
	
	answerVector.push_back(elementPush);
	
	//answerString.push_back(elementPush);
	//cout<<"It's Answer String"<<(answerString[i])<<endl;
	//cout<<"push"<<elementPush<<"carry"<<carry<<endl;
	
	}
	cout<<endl<<endl<<answerString<<endl<<endl;
	
	while(carry!=0){
		answerVector.push_back(carry%10);
		carry=carry/10;
	}
	
	
	
	reverse(answerVector.begin(),answerVector.end());
	
	
}

int main(){
string number;
cout<<"Give The Number"<<endl;
getline(cin,number);

transform(number.begin(),number.end(),number.begin(),::tolower);
//reverse(number.begin(),number.end());

for(int i=0;i<number.length();i++){
//cout<<number[i]-'0'<<endl;
if(number[i]-'0'>9){
	cout<<"Invalid Number"<<endl;
	exit(0);
}
}
summer(number);
//cout<<number<<endl;
cout<<"==============================================="<<endl;
cout<<"Final Answer is ";
for (int j:answerVector){
 cout<<j;
}
cout<<endl<<"==============================================="<<endl;

return 0;
}
